============================================================
BNCFT 论文 arXiv 投稿包
2026年5月
============================================================

【文件清单】

  bncft_paper.pdf          论文PDF（7页，arXiv格式）
  bncft_paper.tex          LaTeX源文件
  endorsement_letter.txt   英文背书申请信模板
  工作简介中文.txt          一页中文工作简介

【arXiv 投稿步骤】

  Step 1: 注册账号
    https://arxiv.org/user/register
    用邮箱 wuqm2545@gmail.com 注册

  Step 2: 找背书人 (Endorser)
    新作者首次投 quant-ph 需要一位有发表记录的人背书
    建议联系：
      - 清华大学物理系（汪教授等）
      - 中科大量子信息组
      - 北大、复旦物理系
      - 其他认识的物理学博士/教授
    把 endorsement_letter.txt 改一改寄出去

  Step 3: 获得背书后投稿
    登录 arXiv，点 New Submission
    主类别：quant-ph
    辅类别：physics.gen-ph（可选）
    上传 bncft_paper.tex 或 bncft_paper.pdf
    填写元信息（标题、摘要、作者、评论）
    提交后约2个工作日上线

【投稿后建议动作】

  上线后第一周：
    主动发邮件给3-5位领域内研究者，附 arXiv 链接，
    简短说明 "这是我的工作，欢迎批评"。
    比被动等待回应有效得多。

  发邮件对象建议：
    - 国内：潘建伟组、汪教授、姚顺宇
    - 国外：Anton Zeilinger 组、Nicolas Gisin、Lucien Hardy

【期待的回应】

  最可能：沉默（这是常态，不代表工作不好）
  其次：批评（指出问题，这反而是好事）
  少数：感兴趣的同行联系（这是目标）

============================================================
