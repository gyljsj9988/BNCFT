#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BNCFT A2 N=8 reference scan v0.1

Purpose
-------
Reference implementation for the A2 finite-dimensional N=8 toy model:
near-commuting readouts, joint-spectrum overlaps, effective-dimension vector,
shared-consistency readouts, and region classification.

Important status note
---------------------
This is a construction / audit script, not a physics result.
All thresholds are schematic A2-level thresholds and must be recalibrated in A3.
The goal is to expose success / fragile / pathological / dangerous-pseudo-success
regions under a reproducible toy-model protocol.

Run
---
python bncft_a2_n8_reference_scan_v0_1.py --outdir ./a2_scan_out

Optional
--------
python bncft_a2_n8_reference_scan_v0_1.py --eta_points 11 --rho_points 11 --delta_points 6
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np
import pandas as pd


# -----------------------------
# Basic linear algebra utilities
# -----------------------------

def sym(A: np.ndarray) -> np.ndarray:
    return 0.5 * (A + A.T)


def fro_norm(A: np.ndarray) -> float:
    return float(np.linalg.norm(A, "fro"))


def spec_norm(A: np.ndarray) -> float:
    return float(np.linalg.norm(A, 2))


def normalize_fro(A: np.ndarray) -> np.ndarray:
    n = fro_norm(A)
    return A if n <= 1e-15 else A / n


def block(A: np.ndarray, B: np.ndarray, C: np.ndarray, D: np.ndarray) -> np.ndarray:
    return np.block([[A, B], [C, D]])


def projector_from_indices(indices: Sequence[int], N: int = 8) -> np.ndarray:
    P = np.zeros((N, N), dtype=float)
    for i in indices:
        P[i, i] = 1.0
    return P


# -----------------------------
# A2 Appendix-A N=8 templates
# -----------------------------

def base_templates(rho: float, sigma: float, tau: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return B^(1), B^(2), B^(3) for the N=8 reference toy model."""
    A_X = np.array(
        [[0, 1, 0, 1],
         [1, 0, 1, 0],
         [0, 1, 0, 1],
         [1, 0, 1, 0]], dtype=float
    )
    A_Y = np.array(
        [[0, 1, 1, 0],
         [1, 0, 0, 1],
         [1, 0, 0, 1],
         [0, 1, 1, 0]], dtype=float
    )
    C = np.eye(4)

    Q_X = np.array(
        [[1, -1, 0, 0],
         [-1, 1, 0, 0],
         [0, 0, 1, -1],
         [0, 0, -1, 1]], dtype=float
    )
    Q_Y = np.array(
        [[1, 0, -1, 0],
         [0, 1, 0, -1],
         [-1, 0, 1, 0],
         [0, -1, 0, 1]], dtype=float
    )
    S = np.array(
        [[1, 0, -1, 0],
         [0, 1, 0, -1],
         [-1, 0, 1, 0],
         [0, -1, 0, 1]], dtype=float
    )

    P_X = np.array(
        [[0, 1, 1, 0],
         [1, 0, 0, 1],
         [1, 0, 0, 1],
         [0, 1, 1, 0]], dtype=float
    )
    P_Y = np.array(
        [[0, 0, 1, 1],
         [0, 0, 1, 1],
         [1, 1, 0, 0],
         [1, 1, 0, 0]], dtype=float
    )
    T = np.array(
        [[0, 1, 0, 0],
         [1, 0, 0, 0],
         [0, 0, 0, 1],
         [0, 0, 1, 0]], dtype=float
    )

    B1 = block(A_X, rho * C, rho * C.T, A_Y)
    B2 = block(Q_X, sigma * S, sigma * S.T, Q_Y)
    B3 = block(P_X, tau * T, tau * T.T, P_Y)
    return B1, B2, B3


def noncommuting_templates() -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return K^(1), K^(2), K^(3)."""
    H1 = np.array(
        [[0, 1, 0, -1],
         [1, 0, -1, 0],
         [0, -1, 0, 1],
         [-1, 0, 1, 0]], dtype=float
    )
    H2 = np.array(
        [[1, 0, 0, -1],
         [0, -1, 1, 0],
         [0, 1, -1, 0],
         [-1, 0, 0, 1]], dtype=float
    )
    H3 = np.array(
        [[0, 0, 1, -1],
         [0, 0, -1, 1],
         [1, -1, 0, 0],
         [-1, 1, 0, 0]], dtype=float
    )
    H1, H2, H3 = normalize_fro(H1), normalize_fro(H2), normalize_fro(H3)
    Z = np.zeros((4, 4), dtype=float)
    K1 = block(Z, H1, H1.T, Z)
    K2 = block(H2, Z, Z, -H2)
    K3 = block(Z, H3, H3.T, Z)
    return K1, K2, K3


def seed_delta_templates() -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Small deterministic seed perturbations Delta_0^(alpha).

    These are not intended as physical assumptions. They provide a reproducible
    non-random local perturbation seed for the first scan.
    """
    Z = np.zeros((4, 4), dtype=float)
    D1x = np.array(
        [[0, 0, 1, 0],
         [0, 0, 0, 0],
         [1, 0, 0, 0],
         [0, 0, 0, 0]], dtype=float
    )
    D1 = block(D1x, Z, Z, Z)

    D2xy = np.array(
        [[0, 0, 1, 0],
         [0, 0, 0, 1],
         [1, 0, 0, 0],
         [0, 1, 0, 0]], dtype=float
    )
    D2 = block(Z, D2xy, D2xy.T, Z)

    D3y = np.array(
        [[0, 1, 0, 0],
         [1, 0, 0, 0],
         [0, 0, 0, 1],
         [0, 0, 1, 0]], dtype=float
    )
    D3 = block(Z, Z, Z, D3y)
    return normalize_fro(sym(D1)), normalize_fro(sym(D2)), normalize_fro(sym(D3))


def project_constraints(A: np.ndarray, eps_cut: float = 1e-12, max_spec_norm: float = 3.0) -> np.ndarray:
    """A2-level constraint projection: symmetrize, sparse cut, spectral cap."""
    B = sym(A)
    if eps_cut > 0:
        B[np.abs(B) < eps_cut] = 0.0
    n = spec_norm(B)
    if n > max_spec_norm and n > 0:
        B = (max_spec_norm / n) * B
    return B


def build_generators(
    eta: float,
    rho: float,
    sigma: float,
    tau: float,
    lambdas: Tuple[float, float, float] = (0.3, 0.3, 0.3),
    eps_cut: float = 1e-12,
    max_spec_norm: float = 3.0,
) -> List[np.ndarray]:
    B1, B2, B3 = base_templates(rho, sigma, tau)
    K1, K2, K3 = noncommuting_templates()
    D1, D2, D3 = seed_delta_templates()
    raw = [
        B1 + lambdas[0] * D1 + eta * K1,
        B2 + lambdas[1] * D2 + eta * K2,
        B3 + lambdas[2] * D3 + eta * K3,
    ]
    return [project_constraints(R, eps_cut=eps_cut, max_spec_norm=max_spec_norm) for R in raw]


# -----------------------------
# Readout calculations
# -----------------------------

def commutator_readouts(Rs: Sequence[np.ndarray], eps: float = 1e-12) -> Dict[str, float]:
    vals = []
    for a, b in [(0, 1), (0, 2), (1, 2)]:
        G = Rs[a] @ Rs[b] - Rs[b] @ Rs[a]
        vals.append(fro_norm(G) / (fro_norm(Rs[a]) * fro_norm(Rs[b]) + eps))
    return {
        "C_avg": float(np.mean(vals)),
        "C_max": float(np.max(vals)),
        "C_var": float(np.var(vals)),
        "c12": float(vals[0]),
        "c13": float(vals[1]),
        "c23": float(vals[2]),
    }


def eigensystem_abs_sorted(R: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    w, v = np.linalg.eigh(R)
    idx = np.argsort(np.abs(w))[::-1]
    return w[idx], v[:, idx]


def principal_projector(R: np.ndarray, k: int) -> Tuple[np.ndarray, np.ndarray]:
    w, v = eigensystem_abs_sorted(R)
    V = v[:, :k]
    return V @ V.T, w


def subspace_overlap(P: np.ndarray, Q: np.ndarray, k: int) -> float:
    return float(np.trace(P @ Q) / k)


def participation_ratio(evals_abs_sorted: np.ndarray) -> float:
    l = np.abs(evals_abs_sorted)
    denom = float(np.sum(l * l))
    if denom <= 1e-15:
        return 0.0
    return float((np.sum(l) ** 2) / denom)


def spectral_gap_dimension(evals_abs_sorted: np.ndarray) -> Tuple[int, float]:
    l = np.abs(evals_abs_sorted)
    gaps = l[:-1] - l[1:]
    k = int(np.argmax(gaps) + 1)
    return k, float(np.max(gaps))


def local_update(
    Rs: Sequence[np.ndarray],
    delta: float,
    support: Sequence[int],
    eps_cut: float = 1e-12,
    max_spec_norm: float = 3.0,
) -> List[np.ndarray]:
    """Deterministic local update supported on S plus a first-neighbour closure.

    Object labels are zero-based in code. For example, the paper's {2,3} is (1,2).
    """
    N = Rs[0].shape[0]
    out = []
    for alpha, R in enumerate(Rs):
        closure = set(support)
        # Use R^(1) to define a first relation-neighbour closure.
        for i in support:
            neighbour_order = np.argsort(np.abs(Rs[0][i]))[::-1]
            closure.update(neighbour_order[:2].tolist())
        closure = sorted(closure)
        P = np.zeros((N, N), dtype=float)
        for idx, i in enumerate(closure):
            for j in closure[idx + 1:]:
                sign = 1.0 if ((i + j + alpha) % 2 == 0) else -1.0
                P[i, j] = sign
                P[j, i] = sign
        P = normalize_fro(P)
        out.append(project_constraints(R + delta * P, eps_cut=eps_cut, max_spec_norm=max_spec_norm))
    return out


def joint_readouts(Rs: Sequence[np.ndarray], marginal_mode: str = "fro") -> Tuple[float, float]:
    """Return (J_XY, O_Y_marginal).

    J_XY follows the A2 schematic trace readout.
    O_Y_marginal defaults to a Frobenius block norm because trace(P_Y R^(3) P_Y)
    can be identically zero for zero-diagonal edge-weight templates.
    """
    N = Rs[0].shape[0]
    P_X = projector_from_indices(range(0, 4), N)
    P_Y = projector_from_indices(range(4, 8), N)
    R2, R3 = Rs[1], Rs[2]
    J = float(np.trace(P_X @ R2 @ P_Y @ R3))
    block_Y = P_Y @ R3 @ P_Y
    if marginal_mode == "trace":
        O = float(np.trace(block_Y))
    elif marginal_mode == "trace_square":
        O = float(np.trace(block_Y @ block_Y))
    else:
        O = fro_norm(block_Y)
    return J, O


def readout_metrics(
    eta: float,
    rho: float,
    delta: float,
    sigma: float = 0.4,
    tau: float = 0.4,
    lambdas: Tuple[float, float, float] = (0.3, 0.3, 0.3),
    k_ref: int = 4,
    update_supports: Sequence[Sequence[int]] = ((1, 2), (1, 2, 5)),
    marginal_mode: str = "fro",
) -> Dict[str, float]:
    Rs = build_generators(eta=eta, rho=rho, sigma=sigma, tau=tau, lambdas=lambdas)
    row: Dict[str, float] = {
        "eta": eta,
        "rho": rho,
        "sigma": sigma,
        "tau": tau,
        "delta": delta,
        "lambda1": lambdas[0],
        "lambda2": lambdas[1],
        "lambda3": lambdas[2],
    }
    row.update(commutator_readouts(Rs))

    projectors = []
    evals = []
    d_pr_values = []
    d_gap_values = []
    gap_values = []
    for R in Rs:
        Pk, w = principal_projector(R, k_ref)
        projectors.append(Pk)
        evals.append(w)
        d_pr_values.append(participation_ratio(w))
        kgap, gval = spectral_gap_dimension(w)
        d_gap_values.append(float(kgap))
        gap_values.append(gval)

    xi_values = [
        subspace_overlap(projectors[0], projectors[1], k_ref),
        subspace_overlap(projectors[0], projectors[2], k_ref),
        subspace_overlap(projectors[1], projectors[2], k_ref),
    ]
    row["xi4_12"], row["xi4_13"], row["xi4_23"] = xi_values
    row["xi4_mean"] = float(np.mean(xi_values))
    row["D_PR"] = float(np.mean(d_pr_values))
    row["D_gap"] = float(np.median(d_gap_values))
    row["D_gap_std"] = float(np.std(d_gap_values))
    row["D_cons"] = float(np.mean(d_gap_values))

    # Stability-based dimension: select k in {2,...,6} with lowest update loss.
    k_losses = {}
    for k in range(2, 7):
        Ps_k = [principal_projector(R, k)[0] for R in Rs]
        losses = []
        for support in update_supports:
            Rs_u = local_update(Rs, delta=delta, support=support)
            for alpha, R_u in enumerate(Rs_u):
                P_u = principal_projector(R_u, k)[0]
                losses.append(1.0 - subspace_overlap(Ps_k[alpha], P_u, k))
        k_losses[k] = float(np.mean(losses))
    row["D_stab"] = float(min(k_losses, key=k_losses.get))

    # Costs at k_ref.
    stability_losses = []
    J0, O0 = joint_readouts(Rs, marginal_mode=marginal_mode)
    delta_J_values = []
    delta_O_values = []
    for support in update_supports:
        Rs_u = local_update(Rs, delta=delta, support=support)
        for alpha, R_u in enumerate(Rs_u):
            P_u = principal_projector(R_u, k_ref)[0]
            stability_losses.append(1.0 - subspace_overlap(projectors[alpha], P_u, k_ref))
        Ju, Ou = joint_readouts(Rs_u, marginal_mode=marginal_mode)
        delta_J_values.append(Ju - J0)
        delta_O_values.append(Ou - O0)

    row["E_unstable"] = float(np.mean(stability_losses))
    row["E_split"] = float(row["D_gap_std"] + (1.0 - row["xi4_mean"]))
    row["deltaJ_max"] = float(np.max(np.abs(delta_J_values)))
    row["deltaMarginal_max"] = float(np.max(np.abs(delta_O_values)))
    row["marginal_mode"] = marginal_mode
    return row


# -----------------------------
# Schematic A2 region classifier
# -----------------------------

def classify_region(row: Dict[str, float], cfg: Dict[str, float]) -> str:
    """Schematic A2-level region classification.

    These thresholds are not physical results. They are placeholders for
    first-pass audit and must be recalibrated in A3.
    """
    near = (
        row["C_avg"] < cfg["C_avg_success"]
        and row["C_max"] < cfg["C_max_success"]
        and row["C_var"] < cfg["C_var_success"]
    )
    xi_good = row["xi4_mean"] > cfg["xi4_success"]
    D_close = all(abs(row[d] - 4.0) <= cfg["eps_D"] for d in ["D_PR", "D_gap", "D_stab", "D_cons"])
    stable = row["E_unstable"] < cfg["E_unstable_success"] and row["E_split"] < cfg["E_split_success"]
    marginal_ok = row["deltaMarginal_max"] <= cfg["eps_marginal"]
    dangerous_marginal = row["deltaMarginal_max"] > cfg["eps_marginal"]

    if near and xi_good and D_close and stable and marginal_ok:
        return "success"
    if near and xi_good and D_close and stable and dangerous_marginal:
        return "dangerous_pseudo_success"

    # Explicit pathology screens.
    if (
        row["C_avg"] > cfg["C_avg_pathological"]
        or row["E_split"] > cfg["E_split_pathological"]
        or row["D_gap_std"] > cfg["D_gap_std_pathological"]
    ):
        return "pathological"

    return "fragile"


def default_thresholds() -> Dict[str, float]:
    return {
        "C_avg_success": 0.22,
        "C_max_success": 0.30,
        "C_var_success": 0.01,
        "xi4_success": 0.46,
        "eps_D": 1.10,
        "E_unstable_success": 0.10,
        "E_split_success": 1.10,
        # Deliberately tight to expose dangerous pseudo-success candidates in early scans.
        "eps_marginal": 0.002,
        "C_avg_pathological": 0.245,
        "E_split_pathological": 1.40,
        "D_gap_std_pathological": 1.00,
    }


def run_scan(args: argparse.Namespace) -> pd.DataFrame:
    eta_values = np.linspace(args.eta_min, args.eta_max, args.eta_points)
    rho_values = np.linspace(args.rho_min, args.rho_max, args.rho_points)
    delta_values = np.linspace(args.delta_min, args.delta_max, args.delta_points)
    cfg = default_thresholds()
    rows = []
    for eta in eta_values:
        for rho in rho_values:
            for delta in delta_values:
                row = readout_metrics(
                    eta=float(eta),
                    rho=float(rho),
                    delta=float(delta),
                    sigma=args.sigma,
                    tau=args.tau,
                    lambdas=(args.lambda1, args.lambda2, args.lambda3),
                    marginal_mode=args.marginal_mode,
                )
                row["label"] = classify_region(row, cfg)
                rows.append(row)
    return pd.DataFrame(rows)


def save_outputs(df: pd.DataFrame, outdir: Path, args: argparse.Namespace) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    csv_path = outdir / "bncft_a2_n8_scan_results.csv"
    df.to_csv(csv_path, index=False)

    summary = {
        "status": "reference_scan_v0.1",
        "note": "Thresholds are schematic A2-level placeholders; A3 must recalibrate them.",
        "rows": int(len(df)),
        "label_counts": {k: int(v) for k, v in df["label"].value_counts().to_dict().items()},
        "parameter_grid": {
            "eta_min": args.eta_min,
            "eta_max": args.eta_max,
            "eta_points": args.eta_points,
            "rho_min": args.rho_min,
            "rho_max": args.rho_max,
            "rho_points": args.rho_points,
            "delta_min": args.delta_min,
            "delta_max": args.delta_max,
            "delta_points": args.delta_points,
            "sigma": args.sigma,
            "tau": args.tau,
            "lambdas": [args.lambda1, args.lambda2, args.lambda3],
            "marginal_mode": args.marginal_mode,
        },
        "thresholds": default_thresholds(),
    }
    with open(outdir / "bncft_a2_n8_scan_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    # Optional plots. Use matplotlib defaults only.
    if args.plots:
        import matplotlib.pyplot as plt

        # Generate heatmaps for each delta slice. To keep output small,
        # plot the middle delta slice only by default.
        mid_delta = sorted(df["delta"].unique())[len(df["delta"].unique()) // 2]
        sl = df[np.isclose(df["delta"], mid_delta)]
        pivot_c = sl.pivot(index="rho", columns="eta", values="C_avg")
        plt.figure()
        plt.imshow(pivot_c.values, origin="lower", aspect="auto",
                   extent=[sl["eta"].min(), sl["eta"].max(), sl["rho"].min(), sl["rho"].max()])
        plt.xlabel("eta")
        plt.ylabel("rho")
        plt.title(f"C_avg heatmap at delta={mid_delta:.3f}")
        plt.colorbar(label="C_avg")
        plt.tight_layout()
        plt.savefig(outdir / "heatmap_C_avg_mid_delta.png", dpi=160)
        plt.close()

        pivot_xi = sl.pivot(index="rho", columns="eta", values="xi4_mean")
        plt.figure()
        plt.imshow(pivot_xi.values, origin="lower", aspect="auto",
                   extent=[sl["eta"].min(), sl["eta"].max(), sl["rho"].min(), sl["rho"].max()])
        plt.xlabel("eta")
        plt.ylabel("rho")
        plt.title(f"xi4_mean heatmap at delta={mid_delta:.3f}")
        plt.colorbar(label="xi4_mean")
        plt.tight_layout()
        plt.savefig(outdir / "heatmap_xi4_mean_mid_delta.png", dpi=160)
        plt.close()

        # Label map encoded as integers, legend stored in JSON.
        label_order = ["success", "fragile", "pathological", "dangerous_pseudo_success"]
        label_to_int = {lab: i for i, lab in enumerate(label_order)}
        sl = sl.copy()
        sl["label_code"] = sl["label"].map(label_to_int)
        pivot_l = sl.pivot(index="rho", columns="eta", values="label_code")
        plt.figure()
        plt.imshow(pivot_l.values, origin="lower", aspect="auto",
                   extent=[sl["eta"].min(), sl["eta"].max(), sl["rho"].min(), sl["rho"].max()])
        plt.xlabel("eta")
        plt.ylabel("rho")
        plt.title(f"Region-label code at delta={mid_delta:.3f}")
        plt.colorbar(label="label code")
        plt.tight_layout()
        plt.savefig(outdir / "heatmap_region_labels_mid_delta.png", dpi=160)
        plt.close()

        with open(outdir / "plot_label_codes.json", "w", encoding="utf-8") as f:
            json.dump(label_to_int, f, indent=2, ensure_ascii=False)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="BNCFT A2 N=8 reference scan v0.1")
    p.add_argument("--outdir", type=str, default="bncft_a2_n8_scan_out")
    p.add_argument("--eta_min", type=float, default=0.0)
    p.add_argument("--eta_max", type=float, default=1.0)
    p.add_argument("--eta_points", type=int, default=11)
    p.add_argument("--rho_min", type=float, default=0.0)
    p.add_argument("--rho_max", type=float, default=1.0)
    p.add_argument("--rho_points", type=int, default=11)
    p.add_argument("--delta_min", type=float, default=0.0)
    p.add_argument("--delta_max", type=float, default=0.5)
    p.add_argument("--delta_points", type=int, default=6)
    p.add_argument("--sigma", type=float, default=0.4)
    p.add_argument("--tau", type=float, default=0.4)
    p.add_argument("--lambda1", type=float, default=0.3)
    p.add_argument("--lambda2", type=float, default=0.3)
    p.add_argument("--lambda3", type=float, default=0.3)
    p.add_argument("--marginal_mode", type=str, default="fro",
                   choices=["fro", "trace", "trace_square"])
    p.add_argument("--plots", action="store_true")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    df = run_scan(args)
    outdir = Path(args.outdir)
    save_outputs(df, outdir, args)
    print(f"Wrote scan outputs to: {outdir}")
    print(df["label"].value_counts().to_string())


if __name__ == "__main__":
    main()
