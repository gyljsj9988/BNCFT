# BNCFT A2 N=8 首轮参考扫描协议 v0.1

## 定位

本协议是 A2 v1.2 的计算施工件，不是物理结果论文。它的目标是把 A2 的 N=8 样板、读出量和区域分类口径落实为可运行的参考实现。

## 文件

- `bncft_a2_n8_reference_scan_v0_1.py`：参考实现脚本。
- `bncft_a2_n8_scan_results.csv`：运行后生成的逐参数点结果表。
- `bncft_a2_n8_scan_summary.json`：运行摘要、参数网格、阈值配置和标签统计。
- 可选 PNG 图：中间 `delta` 切片上的 `C_avg`、`xi4_mean` 和区域标签图。

## 运行方式

```bash
python bncft_a2_n8_reference_scan_v0_1.py --outdir ./a2_scan_out --plots
```

默认扫描网格：

```text
eta   : 11 points in [0, 1]
rho   : 11 points in [0, 1]
delta :  6 points in [0, 0.5]
sigma = 0.4
tau   = 0.4
lambda1=lambda2=lambda3=0.3
```

总计 726 个参数点。

## 输出字段说明

核心字段：

- `C_avg`, `C_max`, `C_var`：近对易读出。
- `xi4_mean`：k=4 主子空间跨探针平均重叠度。
- `D_PR`, `D_gap`, `D_stab`, `D_cons`：有效维数向量四分量。
- `E_split`, `E_unstable`：分裂与稳定代价。
- `deltaJ_max`：联合相关读出变化。
- `deltaMarginal_max`：远端边缘读出变化。
- `label`：区域分类标签。

## 边缘读出说明

A2 正文中的示意边缘读出可写成 trace 型读出。但在零对角边权模板中，`trace(P_Y R^(3) P_Y)` 可能退化为恒零。因此参考实现默认使用 `fro` 模式：

```text
O_Y_marginal = || P_Y R^(3) P_Y ||_F
```

脚本也保留 `--marginal_mode trace` 和 `--marginal_mode trace_square` 以便对照。

## 阈值状态

脚本中的分类阈值是 A2 层的示意阈值，不是最终物理标准。A3 需要对这些阈值进行统计标定与稳健性校准。

## 推荐第一轮检查

1. 先运行默认网格，确认四类标签是否都可能出现。
2. 若全部为 fragile 或 pathological，检查：
   - `eps_marginal` 是否过紧；
   - `xi4_success` 是否过高；
   - `C_avg_success` 是否过低；
   - 非对易增强项是否过强。
3. 对 success 或 dangerous pseudo-success 附近做局部加密扫描。
4. 把代表性参数簇移交 A3/A4：
   - success / fragile / pathological -> A3
   - dangerous pseudo-success -> A4 优先审查

## 解释纪律

该实现只证明“样板可运行”。它不证明：
- 四维时空已经推出；
- Lorentz 符号已经出现；
- 单度规已经成立；
- 无信号定理已经完成；
- GR 或连续 EFT 已经恢复。
